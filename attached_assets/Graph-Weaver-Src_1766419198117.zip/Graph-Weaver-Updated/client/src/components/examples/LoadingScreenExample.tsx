import LoadingScreen from '../LoadingScreen';

export default function LoadingScreenExample() {
  return (
    <div className="w-full h-[400px] relative">
      <LoadingScreen />
    </div>
  );
}
